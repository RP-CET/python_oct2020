#https://www.fortytwo.sg/living-room/coffee-table/nina-coffee-table-brown.html

import bs4
import requests

requestObj = requests.get("https://www.fortytwo.sg/living-room/coffee-table/nina-coffee-table-brown.html")
requestObj.raise_for_status()
soup = bs4.BeautifulSoup(requestObj.text, 'html.parser')

elements = soup.select("#product-price-41537 > span") # $49.90 
print("Current Price: " + elements[0].text)

elements = soup.select("#old-price-41537")  #  $79.00
print("\nOld Price: " + elements[0].text)

